The following readme text is from kin.

---

Read below for an explanation on "noring" vs regular.
I highly recommend regular if you are unsure.

##################################################

There are three components to a ball crosshair.

1. passtime_ball_reticle_passlock
	### This part is ENABLED in every crosshair in this pack. ###
	
	The part you typically aim with. This part will stay perpendicular to the surface it is aimed at.
	In other words, this part responds to the terrain, so you can easily see if the throw arc will hit a wall, floor, edge, etc.
	
2. passtime_ball_reticle_piece_1
	### Using "noring" vpks will DISABLE this part. ###
	### The regular vpks all use the same "ring" for this. ###
	
	This part will stay static and does not "flatten" onto surfaces.
	Some people prefer to disable it for this reason, however it has an important secondary function.
	This part of the crosshair determines the outline around the ball, as well as the "locked on" indicator on teammates.
	For this reason, I prefer to leave this on. 
	(Another side effect: this part will be animated and shown on the enemy goal when you have the ball.)
	
3. passtime_ball_reticle_piece_2
	### This part is DISABLED in every crosshair in this pack. ###
	
	Need to test this part more, but seems to just be another animated segment.
	Could potentially be better than using piece1 for certain applications, will see in future.
	
##################################################

nerd note:
All of the vtfs included are flagged to not use mipmaps. 
I find it much easier to see them with the slight aliasing shimmer.